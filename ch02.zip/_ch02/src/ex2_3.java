
public class ex2_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x =100;
		double pi = 3.14;
		char ch = 'a';
		String str = "abc";
		
		System.out.println(x);
		System.out.println(pi);
		System.out.println(ch);
		System.out.println(str);

	
//		final int score = // 100;
//		final int score = 200;
//		System.out.println(score);
	}

}
