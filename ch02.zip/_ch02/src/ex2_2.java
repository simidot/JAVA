
public class ex2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("6+3");
		System.out.println(6+3);
		
		
		int x = 4, y=2;
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);
	}

}
