
public class ex2_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 4, y= 2;
		int tmp;
		
		tmp = x;
		x = y; 
		y = tmp;
		
		System.out.println("x="+x);
		System.out.println("y="+y);
		
	}

}
